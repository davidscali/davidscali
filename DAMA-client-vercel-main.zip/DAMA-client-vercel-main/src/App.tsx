import './App.css';
import AuthenticatedApp from './AuthenticatedApp';

function App() {
  return (
    <AuthenticatedApp />
  );
}

export default App;
